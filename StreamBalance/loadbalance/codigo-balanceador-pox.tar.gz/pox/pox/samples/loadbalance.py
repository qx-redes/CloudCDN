"""
Make a default forwarding and load balance to streaming servers.

This application should be executed in the same network as streaming servers.
"""

from pox.core import core
from pox.lib.util import dpid_to_str
from pox.lib.packet.ethernet import ethernet, ETHER_BROADCAST
from pox.lib.packet.ipv4 import ipv4
from pox.lib.packet.arp import arp
from pox.lib.addresses import IPAddr, EthAddr

from SimpleXMLRPCServer import SimpleXMLRPCServer
import threading
import os
import inspect

import pox.openflow.libopenflow_01 as of

import time

log = core.getLogger()

FLOW_IDLE_TIMEOUT = 60 * 10

gateway_ip = IPAddr('200.129.39.97')
gateway_mac = EthAddr('f0:4d:a2:e4:c6:e3')

service_ip = IPAddr('200.129.39.110')
service_mac = EthAddr('90:e6:ba:07:77:25')
service_port = 554

client_cloud_ip = IPAddr('200.129.39.112')
client_cloud_mac = EthAddr('02:00:c8:81:27:70')

class ServerThread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.timeToQuit = threading.Event()
        self.timeToQuit.clear()      

    def stop(self):    
        self.server.server_close()
        self.timeToQuit.set()

    def _set_instance(self, instance):
    	self.instance = instance

    def run(self):
        print "Running Server"
        self.server = SimpleXMLRPCServer( (str(service_ip), 8000))
        self.server.register_instance(self.instance)        
        while not self.timeToQuit.isSet():
            self.server.handle_request()

class LoadBalance(object):

	def __init__(self,connection):		
		self.connection = connection
		self.mac = self.connection.eth_addr		
		self.live_servers = {}
		self.servers = []
		self.serverID = 0
		self.service_ip = IPAddr(service_ip);	
		#self.addServer('200.129.39.104','02:00:c8:81:27:68',1) 
		self.addServer('200.129.39.105','02:00:c8:81:27:69',1) 
		#self.addServer('200.129.39.106','02:00:c8:81:27:6a',1)		
		
		connection.addListeners(self)		

		# Send first client requests to the controller.
		fm = of.ofp_flow_mod()
		fm.priority = of.OFP_DEFAULT_PRIORITY
		fm.match.dl_type = ethernet.IP_TYPE
		fm.match.nw_dst = self.service_ip
		fm.match.nw_proto = ipv4.TCP_PROTOCOL
		fm.match.tp_dst = service_port
		fm.actions.append(of.ofp_action_output(port=of.OFPP_CONTROLLER))
		self.connection.send(fm)		

		# Let the non-OpenFlow stack handle everything else.
		fm = of.ofp_flow_mod()
		fm.priority = of.OFP_DEFAULT_PRIORITY - 1
		fm.actions.append(of.ofp_action_output(port=of.OFPP_NORMAL))
		self.connection.send(fm)						

	######### Remote methods available for WebService ###########

	def addServer(self,ip,mac,port=1):
		if ip is not None:
			ip = IPAddr(ip)		
			self.servers.append(ip)
			self.live_servers[ip] = EthAddr(mac),port
			log.debug("Adicionando servidor com IP %s",ip)
		else:
			log.debug("Servidor nao adicionado: IP vazio")

	def delServer(self,ip):
		if ip is not None:
			ip = IPAddr(ip)
			#self.servers.remove(ip)
			del self.live_servers[ip]
			log.debug("Removendo servidor com IP %s",ip)
		else:
			log.debug("Servidor nao removido: IP vazio")

	def listServers(self,teste):
		log.debug("Listando IP dos Servidores")
		for server_ip in self.servers:			
			log.debug("%s",server_ip)
		return self.servers

	#############################################################

	def _pick_server(self):
		
		if (len(self.live_servers) == 0):
			return None

		if self.serverID >= (len(self.servers)-1):
			self.serverID = 0
		else:
			self.serverID = self.serverID + 1

		server = self.servers[self.serverID]

		if self.live_servers[server] is not None:
			return server
		else:
			return self._pick_server()
		
	
	def _handle_PacketIn(self,event):		
		
		in_port = event.port
		packet = event.parsed
		buffer_id = event.ofp.buffer_id
		raw_data = event.ofp.data
		
		def drop ():
			if buffer_id is not None:
				# Kill the buffer
				msg = of.ofp_packet_out(data = event.ofp)
				self.connection.send(msg)
			return None

		log.debug("PacketIn received by %s in port %d", dpid_to_str(event.dpid), in_port)
		tcp_packet = packet.find('tcp')		
		ip_packet = packet.find('ipv4')
		
		if tcp_packet is not None:			
			if ip_packet.dstip == service_ip and packet.dst == service_mac:
				if tcp_packet.dstport == service_port:	
					log.debug("---------------------------------------------")
					log.debug("Realizing Load Balance")
					log.debug("TCP information: srcport=%d dstport=%d", tcp_packet.srcport, tcp_packet.dstport)
					log.debug("IP information: srcip=%s dstip=%s", ip_packet.srcip, ip_packet.dstip)					

					if len(self.servers) == 0:
							log.warn("No servers!")
							return drop()
					# Pick a server for this flow
					server_ip = self._pick_server()

					if server_ip is None:
						log.debug("There is not live servers.")
						return

					log.debug("Directing traffic to %s", str(server_ip))				

					server_mac,server_port = self.live_servers[server_ip]
					client_ip = ip_packet.srcip

					log.debug("Installing RTSP TCP and RTCP/RTP UDP flows for %s -> %s (REDIRECT_PORT: %d)",ip_packet.srcip, server_ip, server_port)

					# Creating RTSP flow rule: Client -> Server
					msg = of.ofp_flow_mod()
					
					if buffer_id != -1 and buffer_id is not None:
						msg.buffer_id = buffer_id					

					msg.idle_timeout=FLOW_IDLE_TIMEOUT
					msg.hard_timeout=of.OFP_FLOW_PERMANENT
					msg.data=event.ofp
					msg.priority = of.OFP_DEFAULT_PRIORITY + 1

					
					if client_ip == client_cloud_ip:											
						msg.match.dl_src = client_cloud_mac
					else:
						msg.match.dl_src = gateway_mac

					msg.match.dl_dst = service_mac
					msg.match.dl_type = ethernet.IP_TYPE
					msg.match.nw_src = client_ip
					msg.match.nw_dst = service_ip
					msg.match.nw_proto = ipv4.TCP_PROTOCOL
					msg.match.tp_src = tcp_packet.srcport	
					msg.match.tp_dst = service_port
					
					msg.actions.append(of.ofp_action_dl_addr.set_src(service_mac))					
					msg.actions.append(of.ofp_action_dl_addr.set_dst(server_mac)) 
					msg.actions.append(of.ofp_action_nw_addr.set_dst(server_ip))
					msg.actions.append(of.ofp_action_output(port=of.OFPP_IN_PORT)) #TODO For multiple interfaces, use server_port

					self.connection.send(msg)

					# Creating RTSP flow rule: Server -> Client

					msg = of.ofp_flow_mod()
					
					msg.idle_timeout=FLOW_IDLE_TIMEOUT
					msg.hard_timeout=of.OFP_FLOW_PERMANENT
					msg.priority = of.OFP_DEFAULT_PRIORITY + 1

					msg.match.dl_src = server_mac
					msg.match.dl_dst = service_mac
					msg.match.dl_type = ethernet.IP_TYPE
					msg.match.nw_src = server_ip
					msg.match.nw_dst = client_ip
					msg.match.nw_proto = ipv4.TCP_PROTOCOL
					msg.match.tp_src = service_port
					msg.match.tp_dst = tcp_packet.srcport

					msg.actions.append(of.ofp_action_dl_addr.set_src(service_mac))
					msg.actions.append(of.ofp_action_nw_addr.set_src(service_ip))
					
					if client_ip == client_cloud_ip:
						msg.actions.append(of.ofp_action_dl_addr.set_dst(client_cloud_mac))					
					else:
						msg.actions.append(of.ofp_action_dl_addr.set_dst(gateway_mac))					

					msg.actions.append(of.ofp_action_output(port = of.OFPP_IN_PORT)) #TODO For multiple interfaces, use server_port

					self.connection.send(msg)

					# Creating RTP/RTCP flow rule: Client -> Server

					msg = of.ofp_flow_mod()									

					msg.idle_timeout=FLOW_IDLE_TIMEOUT
					msg.hard_timeout=of.OFP_FLOW_PERMANENT					
					msg.priority = of.OFP_DEFAULT_PRIORITY + 1

					
					if client_ip == client_cloud_ip:											
						msg.match.dl_src = client_cloud_mac
					else:
						msg.match.dl_src = gateway_mac

					msg.match.dl_dst = service_mac
					msg.match.dl_type = ethernet.IP_TYPE
					msg.match.nw_src = client_ip
					msg.match.nw_dst = service_ip
					msg.match.nw_proto = ipv4.UDP_PROTOCOL					
					
					msg.actions.append(of.ofp_action_dl_addr.set_src(service_mac))					
					msg.actions.append(of.ofp_action_dl_addr.set_dst(server_mac)) 
					msg.actions.append(of.ofp_action_nw_addr.set_dst(server_ip))
					msg.actions.append(of.ofp_action_output(port=of.OFPP_IN_PORT)) #TODO For multiple interfaces, use server_port

					self.connection.send(msg)

					# Creating RTP/RTCP flow rule: Server -> Client

					msg = of.ofp_flow_mod()
					
					msg.idle_timeout=FLOW_IDLE_TIMEOUT
					msg.hard_timeout=of.OFP_FLOW_PERMANENT
					msg.priority = of.OFP_DEFAULT_PRIORITY + 1

					msg.match.dl_src = server_mac
					msg.match.dl_dst = service_mac
					msg.match.dl_type = ethernet.IP_TYPE
					msg.match.nw_src = server_ip
					msg.match.nw_dst = client_ip
					msg.match.nw_proto = ipv4.UDP_PROTOCOL					

					msg.actions.append(of.ofp_action_dl_addr.set_src(service_mac))
					msg.actions.append(of.ofp_action_nw_addr.set_src(service_ip))
					
					if client_ip == client_cloud_ip:
						msg.actions.append(of.ofp_action_dl_addr.set_dst(client_cloud_mac))					
					else:
						msg.actions.append(of.ofp_action_dl_addr.set_dst(gateway_mac))					
					
					msg.actions.append(of.ofp_action_output(port = of.OFPP_IN_PORT)) #TODO For multiple interfaces, use server_port

					self.connection.send(msg)								
		else: 
			log.debug("PacketIn not classified!")

		return	



class load_balance (object):
  
  def __init__ (self):
    core.openflow.addListeners(self)   

  def _handle_ConnectionUp (self, event):
    log.debug("Switch %s has come up.", dpid_to_str(event.dpid))
    lb = LoadBalance(event.connection)
    serverThread = ServerThread()
    serverThread._set_instance(lb)
    serverThread.start()

def launch():
	core.registerNew(load_balance)
	


